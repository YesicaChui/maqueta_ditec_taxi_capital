package com.example.indriver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
